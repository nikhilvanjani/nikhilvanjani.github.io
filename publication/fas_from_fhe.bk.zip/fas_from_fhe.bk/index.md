---
title: 'New Constructions of Functional Adaptor Signatures : Broader Functions and Improved Efficiency'

# Authors
# If you created a profile for a user (e.g. the default `admin` user), write the username (folder name) here
# and it will be replaced with their full name and linked to their profile.
authors:
  - nikhil
  - garrett
  - aravind_t
  - pratik

# Author notes (optional)
# author_notes:
#  - 'Equal contribution'
#  - 'Equal contribution'

date: '2025-09-09T00:00:00Z'
# doi: '10.1145/3658644.3690240'

# Schedule page publish date (NOT publication's date).
publishDate: '2025-09-09T00:00:00Z'

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ['1']

# Publication name and optional abbreviated publication name.
publication: (To Appear) In **IEEE Symposium on Security and Privacy**, 2026 
# publication_short: In *ICW*

abstract: "
Functional adaptor signatures (FAS) are a novel
cryptographic primitive introduced at CCS’24 that enable
privacy-preserving, fine-grained data-payment exchanges
between a seller and a buyer in a trustless and atomic
manner. In this setup, the seller holds sensitive data *x*
(e.g., patient records, climate data), and the buyer specifies
a function *f* (e.g., aggregate, sum). FAS guarantees that
the buyer learns *f (x)* (and nothing beyond) if and only
if the seller receives payment in blockchain-based tokens.
Unlike generic smart contracts, FAS-powered solutions
excel in privacy, efficiency, and compatibility with diverse
blockchain systems. However, prior FAS constructions
were limited to linear functions (where *f* was linear in
*x*), restricting their applicability to more complex and
prevalent applications including data analytics and ML
model evaluations.


In this work, we extend the capabilities of FAS to
support higher-degree functions (*deg ≥ 2*), significantly
broadening its range of applications. Our core contribution
is a novel FAS design leveraging homomorphic encryption,
which simultaneously achieves enhanced efficiency and
compatibility for general functions. This approach diverges
fundamentally from the restricted design in CCS’24
which relied on connections to functional encryption. We
implement our homomorphic encryption-based FAS for
functions arising in applications such as data analytics and
machine learning inference. Remarkably, even for linear
functions, our new design achieves an order-of-magnitude
improvement in performance compared to CCS’24 constructions. 
Furthermore, our solutions seamlessly integrate
with prominent blockchain systems, requiring only a basic
signature verification script on standard transactions,
thus ensuring practical deployability. As a conceptual
contribution, we introduce the general paradigm of a
blockchain-based functional fair exchange (FFE) protocol,
rigorously define buyer and seller fairness, and show that
FAS implies the general goal of FFE.
"

# Summary. An optional shortened abstract.
summary: 

tags: []

# Display this page in the Featured widget?
featured: true

# Custom links (uncomment lines below)
links:
# - name: ePrint
#   url: https://eprint.iacr.org/2024/1523
# - name: arXiv
#   url: https://arxiv.org/abs/2410.11134
# https://ia.cr/2022/1395


# url_pdf: 'uploads/functional-adaptor-signatures.pdf'
url_code: ''
url_dataset: ''
url_poster: ''
url_project: ''
# url_slides: 'uploads/niar-quasi-linear.pptx'
url_source: ''
# url_video: 'https://youtu.be/Ms853nfSAh8?si=azew_K8WSfvlBfg7&t=952'

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder.

# image:
#   caption: 'Image credit: [**Unsplash**](https://unsplash.com/photos/pLCdAaMFLTE)'
#   focal_point: ''
#   preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.

# projects:
#   - example

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
slides: ""
---
